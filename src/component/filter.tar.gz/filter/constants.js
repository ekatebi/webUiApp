const prefix = 'FILTER__';
export const SHOW_FILTER = `${prefix}SHOW_FILTER`;
export const FILTER_CHANGED = `${prefix}FILTER_CHANGED`;
export const SET_SORT_ORDER = `${prefix}SET_SORT_ORDER`;
export const EDIT_SORT_ORDER = `${prefix}EDIT_SORT_ORDER`;
